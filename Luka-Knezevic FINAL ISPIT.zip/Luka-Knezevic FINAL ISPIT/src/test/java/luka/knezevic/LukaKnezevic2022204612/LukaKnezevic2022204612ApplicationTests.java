package luka.knezevic.LukaKnezevic2022204612;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LukaKnezevic2022204612ApplicationTests {

	@Test
	void contextLoads() {
	}

}
