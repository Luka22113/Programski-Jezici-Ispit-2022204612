package luka.knezevic.LukaKnezevic2022204612.DTO;

import java.time.LocalDateTime;


public class PecivaDTO {
    public String imePeciva;
    public int cenaPeciva;

    public PecivaDTO(String imePeciva, int cenaPeciva) {
        this.imePeciva = imePeciva;
        this.cenaPeciva = cenaPeciva;
    }
}
