package luka.knezevic.LukaKnezevic2022204612;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LukaKnezevic2022204612Application {

	public static void main(String[] args) {
		SpringApplication.run(LukaKnezevic2022204612Application.class, args);
	}

}
