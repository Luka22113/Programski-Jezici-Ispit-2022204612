package luka.knezevic.LukaKnezevic2022204612.DTO;

import java.time.LocalDateTime;

public class KupovinaDTO {
    public int brojPeciva;
    public Long pecivoId;
}
